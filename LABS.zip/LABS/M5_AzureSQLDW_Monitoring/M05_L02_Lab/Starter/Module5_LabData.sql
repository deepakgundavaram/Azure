IF OBJECT_ID('DimProduct_Monitoring') is not null
		DROP TABLE DimProduct_Monitoring;
GO		 
CREATE TABLE DimProduct_Monitoring
WITH
(
	DISTRIBUTION = REPLICATE, 
	CLUSTERED INDEX
	(
		[ProductKey] ASC
	)
)
AS
SELECT 
		*
FROM [dbo].[DimProduct] 
GO


IF OBJECT_ID('FactResellerSales_Monitoring') is not null
		DROP TABLE FactResellerSales_Monitoring;
GO		
CREATE TABLE dbo.FactResellerSales_Monitoring
WITH
(
	DISTRIBUTION = HASH ( [ProductKey] ),
	CLUSTERED COLUMNSTORE INDEX
)
AS
SELECT 
		*
FROM 
		[dbo].[FactResellerSales]
GO

IF OBJECT_ID('DimDate_Monitoring') is not null
		DROP TABLE DimDate_Monitoring;
GO	
CREATE TABLE [dbo].[DimDate_Monitoring]
WITH
(
	DISTRIBUTION = REPLICATE, 
	CLUSTERED INDEX([DateKey] ASC)
)
AS
SELECT
		*
FROM
		[dbo].[DimDate]
GO

CREATE NONCLUSTERED INDEX [EnglishProductName_IDX] ON [dbo].[DimProduct_Monitoring]
(
	[EnglishProductName] ASC
)WITH (DROP_EXISTING = OFF)
GO




