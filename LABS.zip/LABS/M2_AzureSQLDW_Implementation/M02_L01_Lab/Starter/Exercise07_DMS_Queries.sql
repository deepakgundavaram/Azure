
-- View the distributed query plan using the EXPLAIN command
EXPLAIN
SELECT *
FROM FactInternetSales
WHERE ProductKey = 313
OPTION (LABEL = 'Exercise 07- Simple Query');



-- Joining two tables with different distribution Columns
EXPLAIN
SELECT *
FROM   [DimCustomer] c
JOIN   FactInternetSales fis ON fis.CustomerKey = c.CustomerKey
OPTION (LABEL = 'Distribution IN-Compatible Join');


/* Now change the distribution to HASH(CustomerKey) */
IF OBJECT_ID('FactInternetSales_DistItem') IS NULL
BEGIN
    CREATE TABLE FactInternetSales_DistCustomerKey
    WITH (DISTRIBUTION = HASH(CustomerKey))
    AS
    SELECT *
    FROM [FactInternetSales];
END

/*Run the Join query again*/
EXPLAIN
SELECT *
FROM   [DimCustomer] c
JOIN   FactInternetSales_DistCustomerKey fis ON fis.CustomerKey = c.CustomerKey
OPTION (LABEL = 'Exercise 07 - Compatible Join');


/*Aggregations*/
EXPLAIN
SELECT [CalendarYear], COUNT(*)
FROM   [FactInternetSales] fis
JOIN   [DimDate] dd on fis.OrderDateKey = dd.DateKey
GROUP BY [CalendarYear]
OPTION (LABEL = 'Exercise 07 - InCompatible Agg');

EXPLAIN
SELECT [CalendarYear], COUNT(*)
FROM   [FactInternetSales] fis
JOIN   [DimDate] dd on fis.OrderDateKey = dd.DateKey
GROUP BY fis.OrderDateKey, [CalendarYear]
OPTION (LABEL = 'Exercise 07 - Compatible Agg');

--Broadcast Move
CREATE TABLE dbo.FactInternetSales_DistItem
WITH (DISTRIBUTION = HASH(ProductKey))
AS
SELECT *
FROM [dbo].[FactInternetSales];
go

/**/
EXPLAIN
SELECT *
FROM   [dbo].[DimProduct] p 
JOIN   dbo.FactInternetSales_DistItem fis ON fis.ProductKey <> p.ProductKey;

-- Change dbo.DimProduct to Replicated
CREATE TABLE dbo.DimProduct_Repl
WITH (DISTRIBUTION =Replicate)
AS
SELECT *
FROM [dbo].[DimProducts];
go
