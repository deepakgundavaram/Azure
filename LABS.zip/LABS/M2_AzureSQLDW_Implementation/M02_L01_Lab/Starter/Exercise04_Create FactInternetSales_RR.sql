CREATE TABLE [dbo].[FactInternetSales_RR]   
WITH   
  (   
    CLUSTERED COLUMNSTORE INDEX,  
    DISTRIBUTION = ROUND_ROBIN  
  )  
AS SELECT * FROM [dbo].[FactInternetSales]
