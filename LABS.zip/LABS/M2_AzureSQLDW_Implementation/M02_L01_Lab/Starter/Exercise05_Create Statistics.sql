CREATE STATISTICS [ProductKey] ON [FactInternetSales_RR] ([ProductKey]);
CREATE STATISTICS [OrderDateKey] ON [FactInternetSales_RR] ([OrderDateKey]);
CREATE STATISTICS [CustomerKey] ON [FactInternetSales_RR] ([CustomerKey]);
CREATE STATISTICS [PromotionKey] ON [FactInternetSales_RR] ([PromotionKey]);
CREATE STATISTICS [SalesOrderNumber] ON [FactInternetSales_RR] ([SalesOrderNumber]);
CREATE STATISTICS [OrderQuantity] ON [FactInternetSales_RR] ([OrderQuantity]);
CREATE STATISTICS [UnitPrice] ON [FactInternetSales_RR] ([UnitPrice]);
CREATE STATISTICS [SalesAmount] ON [FactInternetSales_RR]] ([SalesAmount]);
