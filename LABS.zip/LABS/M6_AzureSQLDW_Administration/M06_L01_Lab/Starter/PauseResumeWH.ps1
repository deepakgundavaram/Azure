﻿$SubscriptionName="MS Internal PMC Primary"
$ResourceGroupName="meerpmcrg"
$ServerName="pmcsql"  # Without database.windows.net
$DatabaseName="meerreadywh"

Login-AzureRmAccount
Get-AzureRmSubscription
Select-AzureRmSubscription -SubscriptionName $SubscriptionName

$database = Get-AzureRmSqlDatabase –ResourceGroupName $ResourceGroupName `
–ServerName $ServerName –DatabaseName $DatabaseName

$resultDatabase = $database | Suspend-AzureRmSqlDatabase

$resultDatabase


$database = Get-AzureRmSqlDatabase –ResourceGroupName $ResourceGroupName `
–ServerName $ServerName –DatabaseName $DatabaseName

$resultDatabase = $database | Resume-AzureRmSqlDatabase

$resultDatabase
