ALTER INDEX ALL ON [dbo].[FactInternetSales] REBUILD


-- Check the rowgorups again, where shouldn't be any with a trim reason MEMORY_LIMITATION
SELECT  SchemaName,
 TableName,
distribution_id,
Compressed_RGs,
AVG_Compressed_RG_rows,
TrimReason
FROM dbo.vw_mon_row_groups
WHERE schemaName = 'dbo'
AND tableName ='FactInternetSales'